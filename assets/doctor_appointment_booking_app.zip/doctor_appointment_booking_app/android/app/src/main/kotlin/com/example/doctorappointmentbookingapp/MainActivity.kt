package com.example.doctorappointmentbookingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
